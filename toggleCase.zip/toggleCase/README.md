This is the *content* of the README for the demo. 
It is a markdown file. 

The `demo` extension featres a simple extension that toggles case of a selected text. If no text is selected, the full cell is modified. 