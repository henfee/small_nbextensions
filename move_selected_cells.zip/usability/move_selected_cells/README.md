## Move selected cells

This is a quick (and dirty) extension - move up or down several selected cell*s*. Moving cells or series of cells via simple keystrokes can be super useful.


It is a bit dirty because it would be better to act on DOM elements and write a correct move_cells() function. 

Cautionary note: It is very probable that such functionality will be available shortly in the official Jupyter notebook. But in the meantime, it could be useful to some people. moving cells or series of cells via simple keystrokes is super useful

Keyboard shortcuts: *Alt-up* and *Alt-down* (works also with single cells!)

**Cell selection**: Cells can be selected using the rubberband (required extension) or via Shift-J and Shift-K
